import React from 'react';  
import { Router } from 'react-router-dom';  
import { Routes, Route } from 'react-router-dom';  
import AddBook from './addBook';  
import HomePage from './HomePage';  
import BrowseBooks from './BrowseBooks';  
import BookDetails from './BookDetails';  
import CategoryBooks from './CategoryBooks';  
import NotFound from './NotFound';  
import Sidebar from './Sidebar';  
import Header from './Header'; 
import CategoriesList from './CAtegoriesList';
import { BookProvider } from '../BookContext'; 

function App() {  
  return (  
  <BookProvider>
 {/* <Router>  */}
    <div className="container">  
      <Header />   
      <CategoriesList/>
      <div className="flex-container">
      <Sidebar />  
      <div className="main-content">  
        <Routes>  
          <Route path="/" element={<HomePage />} />  
          <Route path="/add-book" element={<AddBook />} />  
          <Route path="/browse-books" element={<BrowseBooks />} />  
          {/* <Route path="/books/:category" element={<CategoryBooks />} />   */}
          <Route path="/books/:id" element={<BookDetails />} />  
          <Route path="books/category/:category" element={<CategoryBooks/>} />  
          <Route path="*" element={<NotFound />} />  
        </Routes>  
      </div>  
      </div>
    </div>
     {/* </Router>);  */}
     </BookProvider>
    // </Router>  
    );
    
}  

export default App;  