//BrowseBooks.jsx
import React, { useState, useEffect, useContext } from 'react';  
import { useSelector } from 'react-redux';
import { Link } from 'react-router-dom';  
import { useParams } from 'react-router-dom';
import { BookContext } from '../BookContext';  
import BookList from './BookList';  

function BrowseBooks() {  
  const books = useSelector((state) => state.books.books);
  const { category } = useParams(); 
  const [searchTerm, setSearchTerm] = useState('');  
  const [filteredBooks, setFilteredBooks] = useState(books);  
  //const { books } = useContext(BookContext); 

  useEffect(() => {  
    const lowerCasedSearchTerm = searchTerm.toLowerCase();  
    console.log('Books:', books);
    const filtered = books.filter(book =>   
      (!category || book.category === category) &&
      (book.title.toLowerCase().includes(lowerCasedSearchTerm) ||  
      book.author.toLowerCase().includes(lowerCasedSearchTerm))
    );  
    console.log('FILTERED BOOKS :',filtered);
    setFilteredBooks(filtered);  
  }, [searchTerm, books,category]);  

  // useEffect(() => {  
  //   setFilteredBooks(books); // Reset filtered books whenever books change  
  // }, [books]); 


  useEffect(() => {  
    let filtered = books;  

    if (category) {  
      filtered = filtered.filter(book => book.category === category);  
    }  

    if (searchTerm) {  
      const lowerSearchTerm = searchTerm.toLowerCase();  
      filtered = filtered.filter(book =>  
        book.title.toLowerCase().includes(lowerSearchTerm) ||  
        book.author.toLowerCase().includes(lowerSearchTerm)  
      );  
    }  

    setFilteredBooks(filtered);  
  }, [category, searchTerm, books]); // Important: Add 'books' to the dependency array  

  const handleSearch = (event) => {  
    setSearchTerm(event.target.value);  
  };  


  return (  
    <div className="browse-books">  
      <h2>Browse Books</h2>  
      <input  
        type="text"  className='search-input'
        placeholder="Search by title or author"  
        value={searchTerm}  
        onChange={(e) => {setSearchTerm(e.target.value);
          console.log(e.target.value);
        }  }
      />  {category && <h3>{category.charAt(0).toUpperCase() + category.slice(1)} Books</h3>} 
      {/* Show category title if applicable */}  

      <div><BookList books={filteredBooks} /> </div> 
    </div>  
  );  
}  

export default BrowseBooks;  