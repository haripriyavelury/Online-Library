// rootReducer.js  
import { combineReducers } from 'redux';  
import bookReducer from './reducer';  

const rootReducer = combineReducers({  
  book: bookReducer,  
});  

export default rootReducer; 