// HomePage.jsx  
import React from 'react';  
import { useSelector } from 'react-redux';  
import { Link } from 'react-router-dom';

function HomePage() {  
  const books = useSelector((state) => state.books.books);  

  const popularBooks = [...books]  
    .sort((a, b) => b.rating - a.rating)  
    .slice(0, 5); //top 5 books

  return (  
    <div >  
      <h2>Welcome to the Book Store!</h2> 
      <p><i>Explore your favorite books and authors</i></p> 
      <section>
      <h2>Popular Books</h2>  
      <div className="book-list">  
        {popularBooks.map((book) => (  
          <div className="book-item" key={book.id}>  
            <strong>{book.title}</strong> by {book.author}  
            <p>{book.description}</p>  
            <p>Rating: {book.rating}</p>  
            <Link to={`/books/${book.id}`}>View Details</Link>  
          </div>  
        ))}  
      </div>  
      </section>
        
      <section>  
        <h2>All Books</h2> {/* Entire Book List */}  
        <div className="book-list">   
          {books.map((book) => (  
            <div className="book-item" key={book.id}>  
              <strong>{book.title}</strong> by {book.author}  
              <p>{book.description}</p>  
              <p>Rating: {book.rating}</p>  
              {/* Link to view more details about the book */}  
              <Link to={`/books/${book.id}`}>View Details</Link>  
             
            </div>  
          ))}  
        </div>  
      </section>  

    </div>  
  );  
}  

export default HomePage;  