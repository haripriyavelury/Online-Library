//store.js
import { configureStore, createSlice } from '@reduxjs/toolkit';  

// Initial state  
const initialState = {  
  books: [  
    { id: 1, title: 'The Great Gatsby', author: 'F. Scott Fitzgerald', category:'sci-fi', description: 'A novel about the American dream.', rating: 4.5 },  
    { id: 2, title: '1984', author: 'George Orwell', category:'Fiction', description: 'Dystopian social science fiction novel.', rating: 4.6 },  
    { id: 3, title: 'To Kill a Mockingbird', author: 'Harper Lee', category:'Comic', description: 'A novel about racial injustice.', rating: 4.8 },  
    { id: 4, title: 'The Catcher in the Rye', author: 'J.D. Salinger',  category:'Action-Adventure',description: 'A story about teenage angst.', rating: 4.3 },  
    { id: 5, title: 'The Lord of the Rings', author: 'J.R.R. Tolkien', category:'fantasy', description: 'Epic fantasy...', rating: 4.5 },  
    { id: 6, title: 'Pride and Prejudice', author: 'Jane Austen',  category:'Non-Fiction',description: 'Classic romance...', rating: 4.2 },  
    { id: 7, title: 'Sapiens', author: 'Yuval Noah Harari',  category:'Biography',description: 'A brief history of humankind...', rating: 4.8 },  
    { id: 8, title: 'Sap', author: 'Yuval Noah Harari',  category:'Action-Adventure',description: 'A brief history of humankind...', rating: 4.8 },
    { id: 9, title: 'Sap1', author: 'Yuval Noah Harari',  category:'Biography',description: 'A brief history of humankind...', rating: 4.8 },
    { id: 10, title: 'Sap2', author: 'Yuval Noah Harari',  category:'Fiction',description: 'A brief history of humankind...', rating: 4.8 },
    { id: 11, title: 'Sap3', author: 'Yuval Noah Harari',  category:'Non-Fiction',description: 'A brief history of humankind...', rating: 4.8 },
    { id: 12, title: 'Sap4', author: 'Yuval Noah Harari',  category:'Biography',description: 'A brief history of humankind...', rating: 4.8 },
    { id: 13, title: 'Sap5', author: 'Yuval Noah Harari',  category:'Sci-fi',description: 'A brief history of humankind...', rating: 4.8 },
    { id: 14, title: 'Sap6', author: 'Yuval Noah Harari',  category:'Biography',description: 'A brief history of humankind...', rating: 4.8 },
    { id: 15, title: 'Sap7', author: 'Yuval Noah Harari',  category:'comic',description: 'A brief history of humankind...', rating: 4.8 },
    { id: 16, title: 'Sap8', author: 'Yuval Noah Harari',  category:'Sci-Fi',description: 'A brief history of humankind...', rating: 4.8 },
    { id: 17, title: 'Sap9', author: 'Yuval Noah Harari',  category:'Biography',description: 'A brief history of humankind...', rating: 4.8 },
    { id: 18, title: 'Sap10', author: 'Yuval Noah Harari',  category:'Fantasy',description: 'A brief history of humankind...', rating: 4.8 },
    { id: 19, title: 'Sap11', author: 'Yuval Noah Harari',  category:'comic',description: 'A brief history of humankind...', rating: 4.8 },
    { id: 20, title: 'Sap12', author: 'Yuval Noah Harari',  category:'Biography',description: 'A brief history of humankind...', rating: 4.8 },
  
  ],  
};  

// Create a slice  
const bookSlice = createSlice({  
  name: 'books',  
  initialState,  
  reducers: {  
    addBook: (state, action) => {  
      state.books.push(action.payload);  
    },  
  },  
});  

// Export actions  
export const { addBook } = bookSlice.actions;  
export const selectBooks = state => state.books.books;  

// Create store with the slice reducer  
const store = configureStore({  
  reducer: {  
    books: bookSlice.reducer,  
  },  
});  



// Export the store  
export default store;  