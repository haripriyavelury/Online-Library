import React, { useContext } from 'react';  
import { BookContext } from '../BookContext'; // Adjust the import as necessary  
import { useSelector } from 'react-redux';
import { selectBooks } from '../store';
import { useParams } from 'react-router-dom';
import { Link } from 'react-router-dom';

function CategoryBooks() 
{  
          //const { books } = useContext(BookContext); // Access the books from context  
          const { category } = useParams(); 
        const books =useSelector(selectBooks);
        // const books =useSelector((state)=>state.book.books);
        // const normalizedCategory = category.toLowerCase();  

          // Ensure categories are defined after fetching books  
          const filteredBooks = books.filter(book => book.category.toLowerCase() === category.toLowerCase());  

          //const filteredBooks = [...new Set(books.filter(book => book.category.toLowerCase()))]; // Get unique categories  
        console.log("books by category ",filteredBooks);
        // const filteredBooks = books.filter(book => book.category.toLowerCase() === category.toLowerCase());  
        return (  
            <div className="category-books">  
              <h2>Books list in {category.charAt(0).toUpperCase() + category.slice(1)} category </h2>
                  {filteredBooks.length>0?
                  (<div className="book-list">  

                  {filteredBooks.map((book) => 
                  (  
                    <div className="book-item" key={book.id}>  
                      <p><strong>{book.title}</strong> </p>
                      <p>by {book.author}</p> 
                      
                      <Link to={`/books/${book.id}`}>View Details</Link>   
                    </div>  
                  ))} </div>): ( <p>No such genres available.</p>  
              )}
            </div>  
          );  
}  

export default CategoryBooks;  