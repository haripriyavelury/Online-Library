//AddBook.jsx
import React, { useState } from 'react';  
import { useDispatch } from 'react-redux'; 
import { useNavigate } from 'react-router-dom'; 
import { useContext } from 'react';
import { addBook } from '../store'; // Update path as needed  
import { BookContext } from '../BookContext';

function AddBook() {  
  const [title, setTitle] = useState('');  
  const [author, setAuthor] = useState('');  
  const [category, setCategory] = useState('');  
  const dispatch = useDispatch();  
  const [description, setDescription] = useState('');  
  const [rating, setRating] = useState(''); 
  const [errors, setErrors] = useState({});  

  //const { addBook } = useContext(BookContext); // Use useContext to access addBook  
  const navigate = useNavigate();  

  const validateForm = () => {  
    let errors = {};  
    if (!title) errors.title = 'Title is required';  
    if (!author) errors.author = 'Author is required';  
    if (!category) errors.category = 'Category is required';  
    if (!description) errors.description = 'Description is required';  
    if (!rating) errors.rating = 'Rating is required';  

    setErrors(errors);  
    return Object.keys(errors).length === 0;  
  };  

  const handleSubmit = (e) => {  
    e.preventDefault();  
    
    if (validateForm()) {  
      const newBook = {  
        id: Date.now(),  
        title,  
        author,  
        category,  
        description,  
        rating: parseFloat(rating),  
      };  

    //const newBook = { title, author, description, rating:Number(rating), id: Date.now() };
    
    dispatch(addBook(newBook));  
    setTitle('');  
    setAuthor('');  
    setRating('');
    setDescription('');  
    setRating(''); 
  
 // addBook(newBook);
  //dispatch(addBook(newBook));  
  navigate('/browse-books');  
  }};


  return (  
    <div className="browse-books">
    <h2>Add a New Book</h2> 
    <form onSubmit={handleSubmit}>  

     <div className="form-group">
      <input 
        type="text"  
        value={title}  
        onChange={(e) => setTitle(e.target.value)}  
        placeholder="Book Title"  
        required  
      />  {errors.title && <p className="error">{errors.title}</p>}  
      </div>
      
      <div className="form-group">
      <input 
        type="text"  
        value={author}  
        onChange={(e) => setAuthor(e.target.value)}  
        placeholder="Author"  
        required  
      />    {errors.author && <p className="error">{errors.author}</p>}
      </div>
      
      <div className="form-group">
      <select 
        id="category" 
        value={category}  
        onChange={(e) => setCategory(e.target.value)} >
          <option value="">Select Category</option>  
            <option value="Fiction">Fiction</option>  
            <option value="Non-Fiction">Non-Fiction</option>  
            <option value="Sci-Fi">Sci-Fi</option>  
        required  
      </select>  {errors.category && <p className="error">{errors.category}</p>} 
      </div>
      
      <div className="form-group">
      <input type="number" value={rating} 
      onChange={(e) => setRating(e.target.value)} min="0" max="5"
      placeholder="Rating (0-5)" required />  
      {errors.Rating && <p className="error">{errors.rating}</p>}
      </div>
      
      <div className="form-group">
      <textarea value={description} 
      onChange={(e) => setDescription(e.target.value)} 
      placeholder="Description" required />  
       {errors.Description && <p className="error">{errors.description}</p>}
      </div>

      <button type="submit">Add Book</button>  
    </form>  
    </div>
  );  
}  

export default AddBook;  