//BookList.jsx
import React from 'react';  
import { Link } from 'react-router-dom';  
import { useParams } from 'react-router-dom';  


function BookList({ books }) {  
  return (  
    <div className="book-list">  
    {books.length > 0 ? (  
      books.map(book => (  
        <div key={book.id} className="book-item">  
          <strong>{book.title}</strong> by {book.author}  
          <p>{book.description}</p>  
          <Link to={`/books/${book.id}`}> Details</Link>  
        </div>  
      ))  
    ) : (  
      <p>No books found.</p>  
    )}  
  </div>  
  );  
}  

export default BookList;  