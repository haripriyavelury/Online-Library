//BookDetail.jsx
import { useEffect } from 'react';  
import React from 'react';  
import { useSelector } from 'react-redux';  
import { useParams } from 'react-router-dom';  
import { Link } from 'react-router-dom';

const BookDetails = () => {  
  const { id } = useParams();  
  // const book = useSelector((state) =>  
  //   state.books.books.find((b) => b.id === parseInt(id))  
  // );  
  //const { books } = useContext(BookContext); // Access books from context  
  //const [book, setBook] = useState(null);  
  const books = useSelector((state) => state.books.books);  
  const book = books.find(book => book.id === Number(id));

  // useEffect(() => {  
  //   const foundBook = books.find(book => book.id === parseInt(id)); // Retrieve the book by ID  
  //   setBook(foundBook);  
  // }, [id, books]);  


  if (!book) return <div>Book not found.</div>;  
  
  return (  
    <div>  
      <h2>{book.title}</h2>  
      <p>Author: {book.author}</p>  
      <p>Category: {book.category}</p>
      <p>Description: {book.description}</p>  
      <p>Rating: {book.rating}</p>  
      <Link to="/browse-books">Back to Browse</Link> 
    </div>  
  );  
};  

export default BookDetails;  