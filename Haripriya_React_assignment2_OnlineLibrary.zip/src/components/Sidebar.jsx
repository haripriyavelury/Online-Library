//Sidebar.jsx
import React from 'react';  
import { Link } from 'react-router-dom';  

const Sidebar = () => {  
  return (  
    <div className="sidebar">  
          <Link to="/">Home</Link>    
          <Link to="/add-book">Add Book</Link>  
          <Link to="/browse-books">Browse Books</Link>  
          {/* <Link to="/category-books">Category Books</Link>   */}
        
    </div>  
  );  
};  

export default Sidebar;  