//CategoriesList.jsx
import React from 'react';  
import { Link } from 'react-router-dom';  
import { useSelector } from 'react-redux';  
import { selectBooks } from '../store';  

function CategoriesList() {  
  const books = useSelector(selectBooks);  

  // Get unique genres from books  
  const categories = [...new Set(books.map(book => book.category.toLowerCase()))];   

  return (  
    <div className="categories-pane">  
      {/* <h2>Categories</h2>   */}
     
    
        {categories.map((category) => (    
            <div className="category-list"  key={category}>   
            <Link  to={`/books/category/${category.toLowerCase()}`} className="category-link"> {/* Create link to each category */}  
              {category.charAt(0).toUpperCase() + category.slice(1)}  {/* Capitalize the genre name */}  
            </Link>  
          </div>  
        ))}  
      </div>  
    
  );  
}  

export default CategoriesList;  